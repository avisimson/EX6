package application;
/**
 * Created by Yakir Pinchas and Avi Simson on 08/01/18.
 * Avi id 205789100
 * yakir id 203200530
 */
public interface Player {
	//function gets row and column and plays turn for specific player.
	boolean playTurn(int i, int j);
	//function update possible moves for player.
	void ShowPossibleMoves();
	//put -1 in all possible moves matrix cells.
	void resetPossibleMoves();
	int[][] getPossibleMoves();
}