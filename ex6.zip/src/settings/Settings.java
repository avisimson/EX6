package settings;
/**
 * Created by Yakir Pinchas and Avi Simson on 08/01/18.
 * Avi id 205789100
 * yakir id 203200530
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import static javafx.fxml.FXMLLoader.load;

public class Settings extends Application {
	public static final int screenSize = 600;
    @Override
    public void start(Stage primaryStage) throws Exception{

        try {
            GridPane root = (GridPane) load(getClass().getResource("Settings.fxml"));
            Scene scene = new Scene(root,screenSize, screenSize - 120);
            scene.getStylesheets().add(getClass().getResource("settingsApplication.css").toExternalForm());
            primaryStage.setTitle("Settings");
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}