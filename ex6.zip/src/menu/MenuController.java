package menu;
/**
 * Created by Yakir Pinchas and Avi Simson on 08/01/18.
 * Avi id 205789100
 * yakir id 203200530
 */
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import reversiapp.ReversiGame;
import settings.Settings;
public class MenuController {

    @FXML
    private Button settingsButton;
    @FXML
    private Button startButton;
	@FXML
	private Button endButton;
    @FXML
    protected void openSettings() {
        Settings settings = new Settings();
        Stage stage = (Stage) settingsButton.getScene().getWindow();
        try {
            settings.start(stage);
        } catch (Exception e) {

        }
    }
    @FXML
    protected void startGame() {
    	 ReversiGame reversiGame = new ReversiGame();
         Stage stage = (Stage) startButton.getScene().getWindow();
         try {
        	 reversiGame.start(stage);
         } catch (Exception e) {

         }

    }    
	@FXML
	private void closeButtonAction(){
		//get a handle of the stage
		Stage stage = (Stage) endButton.getScene().getWindow();
		//close the stage
		stage.close();
	}

}