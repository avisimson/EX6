package application;
import java.io.IOException;
/**
 * Created by Yakir Pinchas and Avi Simson on 08/01/18.
 * Avi id 205789100
 * yakir id 203200530
 */
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
public class ReversiGameController implements Initializable{
	@FXML
	private HBox root;
	@FXML
	private Button endButton;
	@FXML
	private Button menuButton;
    @FXML
    Label currPlayer;
    @FXML
    Label p1Score;
    @FXML
    Label p2Score;
	public static final int sizeOfBoard = 500;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		//create board according to "settings"
		Board reversiBoard = new Board("settings.txt", this);
		//read the players of the game
		reversiBoard.setPlayers(new HumanPlayer(reversiBoard.board, 1), new HumanPlayer(reversiBoard.board, 2));
		reversiBoard.setPrefWidth(sizeOfBoard);
		reversiBoard.setPrefHeight(sizeOfBoard);
		root.getChildren().add(0, reversiBoard);
		reversiBoard.draw(); //draw the reversi board of the game until game ends.
		//Handeling resize of Height
		root.heightProperty().addListener((observable, oldValue, newValue) -> {
			double boardNewHeight = newValue.doubleValue() -120;
			reversiBoard.setPrefHeight(boardNewHeight);
			reversiBoard.draw();
		});
		//Handeling resize of Width
		root.widthProperty().addListener((observable, oldValue, newValue) -> {
			double boardNewWidth = newValue.doubleValue() -120;
			reversiBoard.setPrefWidth(boardNewWidth);
			reversiBoard.draw();
		});
	}
	//function takes the game back to main menu.
	@FXML
	public void BackToMenu() throws IOException {
		Menu menu= new Menu();
        Stage stage = (Stage) menuButton.getScene().getWindow();
        try {
            menu.start(stage);
        } catch (Exception e) {
        	System.err.print("back to menu button error.");
        }
	}
	//function handles close button.
	@FXML
	public void ExitGame(){
		//get a handle of the stage
		Stage stage = (Stage) endButton.getScene().getWindow();
		//close the stage
		stage.close();
	}
    public void setCurrentPlayer(String tv) {
       currPlayer.setText(tv);
    }
    public void setp1Score(String score1) {
        p1Score.setText(score1);
    }
    public void setp2Score(String score2) {
        p2Score.setText(score2);
    }
}