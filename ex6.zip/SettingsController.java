package application;
/**
 * Created by Yakir Pinchas and Avi Simson on 08/01/18.
 * Avi id 205789100
 * yakir id 203200530
 */
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;

import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
public class SettingsController {
	public static final String filename = "settings.txt"; //name of file to read data from.
    ObservableList<String> colors = FXCollections.
            observableArrayList("BLACK", "WHITE", "BLUE", "YELLOW", "RED", "CYAN"
            		, "GREEN", "BROWN");
    ObservableList<String> players = FXCollections.
            observableArrayList("player 1", "player 2");
    @FXML
    private Slider sizeSlider;
    @FXML
    private ComboBox<String> color_player1;
    @FXML
    private ComboBox<String> color_player2;
    @FXML
    private ComboBox<String> open_player;
    @FXML
    private Button closeButton;
    @FXML
    //method initialize settings scene by reading its values from file.
    private void initialize() throws IOException {
    	File fileName1 = new File(filename);
		BufferedReader reader;
		try { //read values for settings from file.
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName1)));
			String line = reader.readLine(); //get size of board from file.
			int size = Integer.parseInt(line);
	    	sizeSlider.setValue(size);
	    	line = reader.readLine(); //get color of player 1 from file.
	        color_player1.setValue(line);
	        color_player1.setItems(colors);
	        line = reader.readLine(); //get color of player 2 from file.
	        color_player2.setValue(line);
	        color_player2.setItems(colors);
	        line = reader.readLine(); //get starting player from file.
	        open_player.setValue(line);
	        open_player.setItems(players);
		} catch (FileNotFoundException e) {
			System.err.print("file not found.");
		}
    }
    //method makes us return from settings back to menu.
    @FXML
    protected void ok() throws IOException  {
        String startPlayer = open_player.getValue().toString();
        String colorPlayer1 = color_player1.getValue().toString();
        String colorPlayer2 = color_player2.getValue().toString();
        double b_size = sizeSlider.getValue();
        System.out.println(b_size);
        System.out.println("start player: " + startPlayer +
                "  color Player 1: " + colorPlayer1 +
                "  color Player 2: " + colorPlayer2 );
        //write to file
        writeToFile("settings.txt");
        //return to the menu
        Menu menu= new Menu();
        Stage stage = (Stage) closeButton.getScene().getWindow();
        try {
            menu.start(stage);
        } catch (Exception e) {
        	System.err.print("Exit bottun error.");
        }
    }
    //method writes to settings file his new default values.
    private void writeToFile(String fileName) throws IOException{
		BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
		writer.write(String.valueOf((int)(sizeSlider.getValue())));
		writer.newLine();
		writer.write(color_player1.getValue().toString());
		writer.newLine();
		writer.write(color_player2.getValue().toString());
		writer.newLine();
		writer.write(open_player.getValue().toString());
		writer.close();
    }
}