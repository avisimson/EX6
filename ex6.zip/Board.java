package application;
/**
 * Created by Yakir Pinchas and Avi Simson on 08/01/18.
 * Avi id 205789100
 * yakir id 203200530
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Circle;

public class Board extends GridPane{
	public int[][] board;
	Player playerOne;
	Color playerOneColor;
	Player playerTwo;
	Color playerTwoColor;
	Color possibleColor = Color.GREENYELLOW;
	private int cantPlay = 0;
	public static final Color boardColor = Color.DARKORANGE;
	public static final int radius = 15;
	//variables that state the status of a cell in the board.
	public static final int PLAYERONE = 1;
	public static final int PLAYERTWO = 2;
	public static final int FREE = 0;
	// boolean for the current players turn.
	boolean OneTurn = true;
	//constructor that gets a file and defines the board variables accordingly.
	public Board(String fileName){
		try{
			File fileName1 = new File(fileName);
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName1)));
			String line = reader.readLine();
			//read the size of the board from the file
			int size = Integer.parseInt(line);
			board = new int[size][size];
			//initializing board with 0's
			for(int i = 0 ; i < board.length; i++){
				for(int j = 0; j < board[0].length; j++){
					board[i][j] = FREE;
				}
			}
			//initialize the center of the board
			board[board.length/2][board.length/2] = PLAYERTWO;
			board[(board.length/2) - 1][(board.length/2) - 1] = PLAYERTWO;
			board[(board.length/2)][(board.length/2) - 1] = PLAYERONE;
			board[(board.length/2) - 1][(board.length/2)] = PLAYERONE;
			//read the first player color
			line = reader.readLine();
			playerOneColor = Color.web(line);
			//read the second color
			line = reader.readLine();
			playerTwoColor = Color.web(line);
			//read the start player for the game.
			line = reader.readLine();
			if(line.equals("player 2")) {
				System.out.println(line);
				OneTurn = false;
			}
			//close the file
			reader.close();
			//rethrow exceptions
		} catch(FileNotFoundException e){
			throw new RuntimeException(e);
		} catch(IOException e){
			throw new RuntimeException(e);
		}
	}
	//set players into game.
	public void setPlayers(Player playerOne, Player playerTwo){
		this.playerOne = playerOne;
		this.playerTwo = playerTwo;
	}
	//method gets board and 2 players and defines Board accordingly.
	public Board(int[][] board, Player playerOne, Player playerTwo){
		this.board = board;
		this.playerOne = playerOne;
		this.playerTwo = playerTwo;
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Board.fxml"));
		fxmlLoader.setRoot(this);
		fxmlLoader.setController(this);
		
		try{
			fxmlLoader.load();
		} catch(IOException exception){
			throw new RuntimeException(exception);
		}
	}
	//function gets a possible moves matrix and draw it on board GUI.
	public void drawPossibleMoves(int[][] possibleMoves) {
		int i = 0;
		//divide the board to row and col
		int height = (int)this.getPrefHeight();
		int width = (int)this.getPrefWidth();
		int cellHeight = height / board.length;
		int cellWidth = width / board[0].length;
		while(possibleMoves[i][0] != -1) { //go on all possible moves.
			this.add(new Circle(cellHeight, cellWidth, radius, possibleColor), possibleMoves[i][1], possibleMoves[i][0]);
			i++;
		}
	}
	//method draw the board on GUI and waits for players moves.
	public void draw() {
		this.getChildren().clear();
		//divide the board to row and col
		int height = (int)this.getPrefHeight();
		int width = (int)this.getPrefWidth();
		// divide the row and column to specific one square
		int cellHeight = height / board.length;
		int cellWidth = width / board[0].length;
		//fill the players positions in the board.
		for(int i = 0; i < board.length; i++){
			for(int j = 0; j < board[i].length; j++) {
				this.add(new Rectangle(cellHeight, cellWidth, boardColor), j, i); //draw cell.
				if(board[i][j] == PLAYERONE) { //draw player 1.
					this.add(new Circle(cellHeight, cellWidth, radius, playerOneColor), j, i);
				}
				else if(board[i][j] == PLAYERTWO) { //draw player 2.
					this.add(new Circle(cellHeight, cellWidth, radius, playerTwoColor), j, i);
				}
			}
		}
		//turns of players.
		for(Node node : this.getChildren()) {
			node.setOnMouseClicked(e -> { //get a row and a column from mouse click.
				if(OneTurn && cantPlay < 2) { //player 1 plays turn.
					playerOne.ShowPossibleMoves();
					if(playerOne.getPossibleMoves()[0][0] == -1) { //if player doesn't have possmoves.
						cantPlay++;
					}
					else { //if player can play.
						drawPossibleMoves(playerOne.getPossibleMoves());
						cantPlay = 0;
						while(!playerOne.playTurn(getRowIndex(node), getColumnIndex(node))) {
							continue;
						}
						playerOne.resetPossibleMoves();
					}
					OneTurn = false;
					draw();
				}
				else if(!OneTurn && cantPlay < 2) { //player 2 plays turn.
					playerTwo.ShowPossibleMoves();
					if(playerTwo.getPossibleMoves()[0][0] == -1) { //if player doesn't have possmoves.
						cantPlay++;
					}
					else { //if player can play.
						drawPossibleMoves(playerTwo.getPossibleMoves());
						cantPlay = 0;
						while(!playerTwo.playTurn(getRowIndex(node), getColumnIndex(node))) {
							continue;
						}
						playerTwo.resetPossibleMoves();
					}
					OneTurn = true;
					draw();
				}
				else { //both player cant play-cantPlay == 2.
					return;
				}
			});
		}
	}
}