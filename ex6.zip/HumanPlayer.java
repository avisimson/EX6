package application;
/**
 * Created by Yakir Pinchas and Avi Simson on 08/01/18.
 * Avi id 205789100
 * yakir id 203200530
 */
public class HumanPlayer implements Player {
	public static final int TurnSize = 100;
	public int[][] board; //board of game.
	public int[][] possibleMoves; //matrix of possible moves
	private int sign; //sign of player -- 1 or 2.
	//represent empty cell in board.
	public static final int FREE = 0;
	
	//constructor initialize player with getting the board.
	public HumanPlayer(int[][] board, int sign){
		this.sign = sign;
		this.board = board;
		this.possibleMoves = new int[TurnSize][2]; //initialize.
		//put -1 in all cells of possible moves.
		for(int k = 0; k < TurnSize; k++) {
			possibleMoves[k][0] = -1;
			possibleMoves[k][1] = -1;
		}
	}
	//put -1 in all possible moves matrix cells.
	public void resetPossibleMoves() {
		for(int k = 0; k < TurnSize; k++) {
			possibleMoves[k][0] = -1;
			possibleMoves[k][1] = -1;
		}
	}
	public int[][] getPossibleMoves() {
		return possibleMoves;
	}
	//player plays turn with i,j.
	//return true if there's a problem with i,j values according to possible moves matrix.
	public boolean playTurn(int i, int j){
		int index = 0;
		while(possibleMoves[index][0] != -1) {
			if(possibleMoves[index][0] == i && possibleMoves[index][1] == j) {
				checkUp(i, j, true);
                checkDown(i, j, true);
                checkLeft(i, j, true);
                checkRight(i, j, true);
                checkUpLeft(i, j, true);
                checkUpRight(i, j, true);
                checkDownLeft(i, j, true);
                checkDownRight(i, j, true);
				board[i][j] = sign;
				return true;
			}
		}
		//input wasn't in possible moves.
		return false;
	}
	//function update possible moves for player.
	public void ShowPossibleMoves() {
		int i, j, count = 0;
		int size = board.length;
	    for(i = 0; i < size; i++) {
	        for(j = 0; j < size; j++) {
	            if(board[i][j] == FREE) {
	                if(checkUp(i, j, false)
	                   || checkDown(i, j, false)
	                   || checkLeft(i, j, false)
	                   || checkRight(i, j, false)
	                   || checkUpLeft(i, j, false)
	                   || checkUpRight(i, j, false)
	                   || checkDownLeft(i, j, false)
	                   || checkDownRight(i, j, false)) {
	                    possibleMoves[count][0] = i;
	                    possibleMoves[count][1] = j;
	                    count++;
	                }
	            }
	        }
	    }
	}
	//function check for  possible moves for an i,j point,
	//and flips disc if boolean flip is true.
	//return: true if possible move or false if not.
	//par: sign of player, i,j of point int board and flip.
	//if flip is true so play the possible move and if false just check it.
	boolean checkLeft(int i, int j, boolean flip) {
	    int count2 = 0; //counts other player showings.
	    if(i == 1 || i == 0) {
	        return false;
	    } else {
	        i--;
	        while(i > 0) {
	            if(board[i][j] != sign
	               && board[i][j] != FREE) {
	                count2++;
	            }
	            if(board[i][j] == sign) {
	                if(count2 > 0) {
	                    //change disc if flip is true.
	                    if(flip) {
	                        while(count2 > 0) {
	                            board[i + count2][j] = sign;
	                            count2--;
	                        }
	                    }
	                    return true;
	                }
	                return false;
	            }
	            if(board[i][j] == FREE) {
	                return false;
	            }
	            i--;
	        }
	        return false;
	    }
	}
	//function check for  possible moves for an i,j point,
	//and flips disc if boolean flip is true.
	//return: true if possible move or false if not.
	boolean checkDown(int i, int j, boolean flip) {
		int size = board.length;
	    int count2 = 0; //counts other player showings.
	    if(j == size - 2 || j == size - 1) {
	        return false;
	    } else {
	        j++;
	        while(j < size) {
	            if(board[i][j] != sign
	               && board[i][j] != FREE) {
	                count2++;
	            }
	            if(board[i][j] == sign) {
	                if(count2 > 0) {
	                    //change disc if flip is true.
	                    if(flip) {
	                        while(count2 > 0) {
	                            board[i][j - count2] = sign;
	                            count2--;
	                        }
	                    }
	                    return true;
	                }
	                return false;
	            }
	            if(board[i][j] == FREE) {
	                return false;
	            }
	            j++;
	        }
	        return false;
	    }
	}
	//function check for  possible moves for an i,j point,
	//and flips disc if boolean flip is true.
	//return: true if possible move or false if not.
	boolean checkRight(int i, int j, boolean flip) {
		int size = board.length;
	    int count2 = 0; //counts other player showings.
	    if(i == size - 2 || i == size - 1) {
	        return false;
	    } else {
	        i++;
	        while(i < size) {
	            if(board[i][j] != sign
	               && board[i][j] != FREE) {
	                count2++;
	            }
	            if(board[i][j] == sign) {
	                if(count2 > 0) {
	                    //change disc if flip is true.
	                    if(flip) {
	                        while(count2 > 0) {
	                            board[i - count2][j] = sign;
	                            count2--;
	                        }
	                    }
	                    return true;
	                }
	                return false;
	            }
	            if(board[i][j] == FREE) {
	                return false;
	            }
	            i++;
	        }
		    return false;
	    }
	}
	//function check for  possible moves for an i,j point,
	//and flips disc if boolean flip is true.
	//return: true if possible move or false if not.
	boolean checkUp(int i, int j, boolean flip) {
	    int count2 = 0; //counts other player showings.
	    if(j == 0 || j == 1) {
	        return false;
	    } else {
	        j--;
	        while(j >= 0) {
	            if(board[i][j] != sign
	               && board[i][j] != FREE) {
	                count2++;
	            }
	            if(board[i][j] == sign) {
	                if(count2 > 0) {
	                    //change disc if flip is true.
	                    if(flip) {
	                        while(count2 > 0) {
	                            board[i][j + count2] = sign;
	                            count2--;
	                        }
	                    }
	                    return true;
	                }
	                return false;
	            }
	            if(board[i][j] == FREE) {
	                return false;
	            }
	            j--;
	        }
	        return false;
	    }
	}
	//function check for  possible moves for an i,j point,
	//and flips disc if boolean flip is true.
	//return: true if possible move or false if not.
	boolean checkUpLeft(int i, int j, boolean flip) {
	    int count2 = 0; //counts other player showings.
	    if(j == 1 || j == 0 || i == 1 || i == 0) {
	        return false;
	    } else {
	        j--;
	        i--;
	        while(j >= 0 && i >= 0) {
	            if(board[i][j] != sign
	               && board[i][j] != FREE) {
	                count2++;
	            }
	            if(board[i][j] == sign) {
	                if(count2 > 0) {
	                    //change disc if flip is true.
	                    if(flip) {
	                        while(count2 > 0) {
	                            board[i + count2][j + count2] = sign;
	                            count2--;
	                        }
	                    }
	                    return true;
	                }
	                return false;
	            }
	            if(board[i][j] == FREE) {
	                return false;
	            }
	            j--;
	            i--;
	        }
	        return false;
	    }
	}
	//function check for  possible moves for an i,j point,
	//and flips disc if boolean flip is true.
	//return: true if possible move or false if not.
	boolean checkUpRight(int i, int j, boolean flip) {
	    int count2 = 0; //counts other player showings.
	    int size = board.length;
	    if(j == size - 1 || j == size - 2 || i == 1 || i == 0) {
	        return false;
	    } else {
	        j++;
	        i--;
	        while(j < size && i >= 0) {
	            if(board[i][j] != sign
	               && board[i][j] != FREE) {
	                count2++;
	            }
	            if(board[i][j] == sign) {
	                if(count2 > 0) {
	                    //change disc if flip is true.
	                    if(flip) {
	                        while(count2 > 0) {
	                            board[i + count2][j - count2] = sign;
	                            count2--;
	                        }
	                    }
	                    return true;
	                }
	                return false;
	            }
	            if(board[i][j] == FREE) {
	                return false;
	            }
	            j++;
	            i--;
	        }
	        return false;
	    }
	}
	//function check for  possible moves for an i,j point,
	//and flips disc if boolean flip is true.
	//return: true if possible move or false if not.
	boolean checkDownLeft(int i, int j, boolean flip) {
	    int count2 = 0; //counts other player showings.
	    int size = board.length;
	    if(j == 1 || j == 0 || i == size - 1 || i == size - 2) {
	        return false;
	    } else {
	        j--;
	        i++;
	        while(j >= 0 && i < size) {
	            if(board[i][j] != sign
	               && board[i][j] != FREE) {
	                count2++;
	            }
	            if(board[i][j] == sign) {
	                if(count2 > 0) {
	                    //change disc if flip is true.
	                    if(flip) {
	                        while(count2 > 0) {
	                            board[i - count2][j + count2] = sign;
	                            count2--;
	                        }
	                    }
	                    return true;
	                }
	                return false;
	            }
	            if(board[i][j] == FREE) {
	                return false;
	            }
	            j--;
	            i++;
	        }
	        return false;
	    }
	}
	//function check for  possible moves for an i,j point,
	//and flips disc if boolean flip is true.
	//return: true if possible move or false if not.
	boolean checkDownRight(int i, int j, boolean flip) {
	    int count2 = 0; //counts other player showings.
	    int size = board.length;
	    if(j == size - 1 || j == size - 2 || i == size - 1 || i == size - 2) {
	        return false;
	    } else {
	        j++;
	        i++;
	        while(j < size && i < size) {
	            if(board[i][j] != sign
	               && board[i][j] != FREE) {
	                count2++;
	            }
	            if(board[i][j] == sign) {
	                if(count2 > 0) {
	                    //change disc if flip is true.
	                    if(flip) {
	                        while(count2 > 0) {
	                            board[i - count2][j - count2] = sign;
	                            count2--;
	                        }
	                    }
	                    return true;
	                }
	                return false;
	            }
	            if(board[i][j] == FREE) {
	                return false;
	            }
	            j++;
	            i++;
	        }
	        return false;
	    }
	}
}